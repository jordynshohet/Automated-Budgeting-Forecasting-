# Testing Documentation — Spectrum Automated Planning Tool

## Overview

This document records the Chrome DevTools testing session performed on the `index.html` budgeting app. Testing covered all 6 tabs, interactive features, data integrity, and console health.

## Tools Used

- **Chrome DevTools MCP** — programmatic browser control (navigation, clicking, screenshots, script evaluation, snapshot inspection)
- **Console monitoring** — checked for JavaScript errors/warnings after load and after all interactions
- **Script evaluation** — ran data validation checks directly against the in-memory forecast engine

## Test Environment

- File opened via `file:///` protocol in Chrome
- No external server required (self-contained HTML with inline JS and CDN-loaded Chart.js)

---

## Tab-by-Tab Testing

### 1. Overview Tab

**How tested:**
- Navigated to the page, confirmed initial render via screenshot
- Verified KPI cards display correct values (Full Year Resource Cost, AWS Cost, CapEx, OpEx)
- Scrolled to verify all 6 charts render (Monthly Resource, Monthly AWS, Business Unit doughnut, Employee Type doughnut, AWS Owner Type doughnut, Total Budget Split doughnut)

**Results:**
- Executive summary narrative renders with correct total ($7,124,649)
- AWS cost shows "within" the $2.1M cap (green text)
- All Chart.js canvases render without errors
- Bar charts show seasonal pattern (lower summer/December)

### 2. Resource Forecast Tab

**How tested:**
- Clicked "Resource Forecast" nav button
- Verified KPI cards (Capital Projects, Operating Projects, FTE Cost, Contractor Cost)
- Scrolled to check horizontal bar chart (Cost by Project), leader chart, CapEx vs OpEx stacked chart
- Verified Project Cost Summary table renders all 20 projects with correct sorting (descending by Full Year)

**Results:**
- Table includes color-coded classification badges (blue for Capital, green for Operating)
- Cost by Leader (SVP) table shows 5 leaders sorted by cost
- Charts render with stacked Actuals (Q1) vs Forecast (Apr-Dec) breakdown

### 3. AWS Hosting Tab

**How tested:**
- Clicked "AWS Hosting" nav button
- Verified 5 KPI cards including "Raw Forecast (No Cap)" with scale factor
- Checked monthly bar chart with budget run rate dashed line ($175K/mo)
- Verified Top 10 Accounts horizontal bar chart
- Verified 5% Growth Accounts Trajectory line chart (3 accounts)
- Scrolled through 45-account summary table

**Results:**
- Full Year AWS Spend: $2,063,636 (under $2.1M cap by $36,364)
- Scale factor: 1.0000 (no cap reduction needed)
- Growth accounts (AWS00008, AWS00011, AWS00027) show "5% MoM Growth (seasonal)" method badge
- All other accounts show "3-Mo Avg +/- $300" method

### 4. Detail Tables Tab

**How tested:**
- Clicked "Detail Tables" nav button
- Verified CSV download button renders
- Checked Employee Forecast Summary table (Apr-Dec) with all 30 employees
- Verified sorting (descending by Total Cost)

**Results:**
- Table displays ID, Name, Type, Rate, Total Hours, Total Cost, and Projects assigned
- Top employee: Marcus Chen (FTE, $120/hr, 1266 hours, $151,920)
- Projects column shows comma-separated list of assigned work

### 5. Assumptions & Methodology Tab

**How tested:**
- Clicked "Assumptions & Methodology" nav button
- Verified yellow assumptions box and narrative sections render

**Results:**
- All 11 model assumptions listed with proper formatting
- Forecasting methodology narrative explains both resource and AWS approaches
- AI Narrative section provides organizational context

### 6. Scenario Builder Tab

**How tested:**
- Clicked "Scenario Builder" nav button
- Verified two-column layout (roster on left, project area on right)
- Created a new project "Cloud Migration" (CapEx, Technology, 40 hrs/mo) via form
- Assigned 3 employees (Marcus Chen, Sarah Whitfield, Brandon Reeves) programmatically
- Verified forecast recalculation ($151,420 FY)
- Tested roster filter (typed "carlos" → showed only Carlos Medina)
- Scrolled to verify stacked bar chart shows monthly seasonality pattern

**Results:**
- Project creation works with all form fields (name, classification, BU, hours)
- Employee chips appear in drop zone with rate and remove (×) button
- Seasonality inputs pre-filled with default values (12 months)
- Metrics cards update live (Total Projects, People Assigned, Annual Forecast, Avg Monthly, CapEx, OpEx)
- Chart shows expected seasonal dip (Jul 85%, Dec 80%)

---

## Data Integrity Validation

Ran JavaScript validation scripts against the in-memory data to confirm model correctness:

| Check | Expected | Actual | Status |
|---|---|---|---|
| CapEx + OpEx = Total Resource Cost | Equal | $5,061,013 = $5,061,013 | ✅ Pass |
| AWS total ≤ $2.1M cap | Under | $2,063,636 (under by $36,364) | ✅ Pass |
| No employee exceeds 160 hrs/month | 0 violations | 0 violations | ✅ Pass |
| PTO caps (FTE ≤ 160 hrs/yr, Contractor ≤ 120 hrs/yr) | 0 violations | 0 violations | ✅ Pass |
| P00010 (WiFi) ends after August | 0 hours Sep-Dec | 0 hours | ✅ Pass |
| P00014 (CPE) ends after August | 0 hours Sep-Dec | 0 hours | ✅ Pass |
| AWS growth accounts compound at 5% MoM | Increasing trajectory | Confirmed (e.g., AWS00008: $3654→$4859) | ✅ Pass |
| Roster count | 30 total | 17 FTE + 13 Contractors = 30 | ✅ Pass |
| Project count | 20 | 20 | ✅ Pass |
| AWS account count | 45 | 45 | ✅ Pass |
| Resource data rows | Actuals + Forecast | 292 actuals + 926 forecast = 1,218 | ✅ Pass |

---

## Console Health

| Stage | Errors | Warnings |
|---|---|---|
| After initial page load | 0 | 0 |
| After navigating all 6 tabs | 0 | 0 |
| After Scenario Builder interactions | 0 | 0 |

---

## Known Issue Found

**Narrative text mismatch:** The Assumptions & Methodology tab states "20 FTEs, 10 contractors" but the actual roster contains 17 FTEs and 13 contractors. This is a hardcoded narrative string that should be updated to reflect the real data.

---

## How to Reproduce This Testing

1. Open `index.html` in Chrome
2. Open DevTools (F12) → Console tab to monitor for errors
3. Click through each navigation tab and visually verify charts/tables render
4. For Scenario Builder: create a project, drag employees in, verify calculations
5. Run the following in Console to validate data integrity:

```javascript
// Quick validation script
const totalRes = resourceData.reduce((s, r) => s + r.cost, 0);
const totalAws = awsData.reduce((s, r) => s + r.cost, 0);
const capex = resourceData.filter(r => r.acctClass === 'Capital Expense').reduce((s,r) => s + r.cost, 0);
const opex = resourceData.filter(r => r.acctClass === 'Operating Expense').reduce((s,r) => s + r.cost, 0);

console.log('Resource Total:', totalRes);
console.log('AWS Total:', totalAws);
console.log('CapEx + OpEx match:', capex + opex === totalRes);
console.log('AWS under cap:', totalAws <= 2100000);

// Check 160-hr cap
const empMonthHours = {};
resourceData.forEach(r => {
    const key = `${r.eid}-${r.month}`;
    empMonthHours[key] = (empMonthHours[key] || 0) + r.hours;
});
const overages = Object.entries(empMonthHours).filter(([k, v]) => v > 160);
console.log('160-hr violations:', overages.length);

// Check PTO caps
const ptoByEmp = {};
resourceData.filter(r => r.proj === 'P00015').forEach(r => {
    if (!ptoByEmp[r.eid]) ptoByEmp[r.eid] = { type: r.type, total: 0 };
    ptoByEmp[r.eid].total += r.hours;
});
const ptoViolations = Object.entries(ptoByEmp).filter(([eid, d]) => 
    d.total > (d.type === 'FTE' ? 160 : 120)
);
console.log('PTO cap violations:', ptoViolations.length);

// Check project endings
const p10After = resourceData.filter(r => r.proj === 'P00010' && r.monthNum > 8);
const p14After = resourceData.filter(r => r.proj === 'P00014' && r.monthNum > 8);
console.log('P00010 hours after Aug:', p10After.reduce((s,r) => s + r.hours, 0));
console.log('P00014 hours after Aug:', p14After.reduce((s,r) => s + r.hours, 0));
```
