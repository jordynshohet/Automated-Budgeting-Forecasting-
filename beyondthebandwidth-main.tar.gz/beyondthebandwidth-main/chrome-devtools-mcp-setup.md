# Chrome DevTools MCP — Setup Guide

This workspace uses a locally-installed Chrome DevTools MCP server. Run the setup script once after cloning.

## Quick Start

```powershell
# From the repo root:
.\setup-mcp.ps1
```

This downloads Node.js portable and installs `chrome-devtools-mcp` into `tools/node/` (gitignored). After running, restart Kiro or reconnect the MCP server.

## What gets installed

```
tools/                             # gitignored — not committed
└── node/                          # Portable Node.js v22.17.1 (win-x64)
    ├── node.exe                   # Node runtime
    ├── chrome-devtools-mcp.cmd    # MCP server entrypoint
    └── node_modules/              # chrome-devtools-mcp + dependencies
```

The workspace MCP config at `.kiro/settings/mcp.json` is committed and points at `./tools/node/chrome-devtools-mcp.cmd`.

## What it does

The `chrome-devtools-mcp` server (from the [ChromeDevTools team](https://github.com/ChromeDevTools/chrome-devtools-mcp)) gives AI agents 27+ browser automation tools — DOM inspection, screenshots, network monitoring, console access, performance profiling, JavaScript execution, and more.

## Usage

Once connected (check the MCP Server view in the Kiro panel), you can ask things like:

- "Navigate to localhost:3000 and take a screenshot"
- "Check the console for errors on this page"
- "Inspect the DOM for accessibility issues"
- "Run a performance trace on this page"
- "Execute JavaScript in the browser console"

## Troubleshooting

### Server shows as disconnected

1. Open the MCP Server view in the Kiro panel
2. Click reconnect next to `chrome-devtools`
3. Or search the command palette for "MCP" commands

### "Could not connect to Chrome"

The server launches Chrome by default. If Chrome isn't installed or you prefer Edge:

Edit `.kiro/settings/mcp.json` and add `--executablePath` to the args:

```json
{
  "mcpServers": {
    "chrome-devtools": {
      "command": "./tools/node/chrome-devtools-mcp.cmd",
      "args": [
        "--executablePath=%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe"
      ],
      "env": {
        "PATH": "./tools/node"
      },
      "disabled": false,
      "autoApprove": []
    }
  }
}
```

### Auto-connect to an already-running browser

Useful when you need to maintain login sessions or existing state:

1. Start your browser with remote debugging: `chrome.exe --remote-debugging-port=9222`
2. Update args:

```json
"args": ["--autoConnect", "--user-data-dir=%LocalAppData%\\Google\\Chrome\\User Data"]
```

## Updating the bundled server

To update to a newer version of `chrome-devtools-mcp`:

```powershell
$nodePath = ".\tools\node"
$env:PATH = "$((Resolve-Path $nodePath).Path);$env:PATH"
& "$nodePath\npm.cmd" install -g chrome-devtools-mcp@latest --prefix "$nodePath"
```

## How this was built

1. Downloaded Node.js v22.17.1 portable (win-x64 zip) from nodejs.org
2. Extracted to `tools/node/`
3. Ran `npm install -g chrome-devtools-mcp@latest --prefix tools/node`
4. Added `.kiro/settings/mcp.json` pointing at the bundled `chrome-devtools-mcp.cmd`

No admin rights required. No system PATH changes. Fully self-contained.

## References

- [chrome-devtools-mcp GitHub](https://github.com/ChromeDevTools/chrome-devtools-mcp)
- [Microsoft Edge + DevTools MCP](https://learn.microsoft.com/en-us/microsoft-edge/web-platform/devtools-mcp-server)
