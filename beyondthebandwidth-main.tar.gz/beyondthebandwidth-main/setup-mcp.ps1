# Setup Chrome DevTools MCP Server
# Run this once after cloning to install the bundled MCP server locally.
# Requires: internet access. No admin rights needed.

$ErrorActionPreference = "Stop"
$toolsDir = Join-Path $PSScriptRoot "tools\node"

if (Test-Path (Join-Path $toolsDir "node.exe")) {
    Write-Host "Node.js already installed at $toolsDir" -ForegroundColor Green
} else {
    Write-Host "Downloading Node.js v22.17.1 portable..." -ForegroundColor Cyan
    $nodeUrl = "https://nodejs.org/dist/v22.17.1/node-v22.17.1-win-x64.zip"
    $zipPath = Join-Path $env:TEMP "node-portable.zip"
    
    Invoke-WebRequest -Uri $nodeUrl -OutFile $zipPath
    
    Write-Host "Extracting to $toolsDir..." -ForegroundColor Cyan
    New-Item -ItemType Directory -Path $toolsDir -Force | Out-Null
    Expand-Archive -Path $zipPath -DestinationPath (Join-Path $PSScriptRoot "tools") -Force
    
    # Move contents up from nested folder
    $extracted = Get-ChildItem (Join-Path $PSScriptRoot "tools\node-v22.17.1-win-x64") 
    $extracted | Move-Item -Destination $toolsDir -Force
    Remove-Item (Join-Path $PSScriptRoot "tools\node-v22.17.1-win-x64") -Force
    Remove-Item $zipPath -Force
    
    Write-Host "Node.js installed." -ForegroundColor Green
}

# Install chrome-devtools-mcp
$cdmPath = Join-Path $toolsDir "node_modules\chrome-devtools-mcp"
if (Test-Path $cdmPath) {
    Write-Host "chrome-devtools-mcp already installed." -ForegroundColor Green
} else {
    Write-Host "Installing chrome-devtools-mcp..." -ForegroundColor Cyan
    $env:PATH = "$toolsDir;$env:PATH"
    & (Join-Path $toolsDir "npm.cmd") install -g chrome-devtools-mcp@latest --prefix $toolsDir
    Write-Host "chrome-devtools-mcp installed." -ForegroundColor Green
}

Write-Host ""
Write-Host "Done! The MCP server is ready. Restart Kiro or reconnect the MCP server." -ForegroundColor Green
Write-Host "Config is at: .kiro/settings/mcp.json" -ForegroundColor Gray
