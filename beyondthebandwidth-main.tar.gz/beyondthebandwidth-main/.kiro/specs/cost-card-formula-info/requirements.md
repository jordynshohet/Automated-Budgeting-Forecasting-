# Requirements Document

## Introduction

This feature adds an information button (ℹ️ icon) to each cost card in the Spectrum Automated Planning Tool. The info button reveals the formula or calculation methodology used to generate the number displayed on that card. This provides transparency into how each cost figure is derived, helping users understand and trust the automated forecasting output.

## Glossary

- **Cost_Card**: A UI component using the `.card` CSS class that displays a metric value (`.value`) and subtitle text (`.sub`) within the planning tool dashboard.
- **Info_Button**: A small clickable icon (ℹ️) positioned within a Cost_Card that triggers display of formula information.
- **Formula_Tooltip**: A popup or overlay element that appears near the Info_Button to display the calculation formula for the associated Cost_Card value.
- **Render_Function**: A JavaScript function (renderOverview, renderResource, renderAWS) that dynamically generates tab content including Cost_Cards.
- **Overview_Tab**: The main dashboard tab showing high-level budget totals for resources and AWS.
- **Resource_Tab**: The tab showing resource cost breakdowns by classification and employee type.
- **AWS_Tab**: The tab showing AWS hosting cost details including cap enforcement.

## Requirements

### Requirement 1: Info Button Placement

**User Story:** As a budget analyst, I want to see an info icon on each cost card, so that I can identify which cards have formula details available.

#### Acceptance Criteria

1. THE Info_Button SHALL appear as a visible ℹ️ icon within each Cost_Card across the Overview_Tab, Resource_Tab, and AWS_Tab.
2. THE Info_Button SHALL be positioned in the top-right area of the Cost_Card header row, adjacent to the card title.
3. THE Info_Button SHALL have a font size and styling that is visually subordinate to the Cost_Card value but clearly clickable.
4. THE Info_Button SHALL not alter the existing layout or spacing of the Cost_Card value or subtitle text.

### Requirement 2: Formula Tooltip Display on Interaction

**User Story:** As a budget analyst, I want to see the formula when I interact with the info icon, so that I can understand how each number was calculated.

#### Acceptance Criteria

1. WHEN a user clicks the Info_Button, THE Formula_Tooltip SHALL appear near the Info_Button showing the formula text for that Cost_Card.
2. WHEN a user hovers over the Info_Button for 300 milliseconds or more, THE Formula_Tooltip SHALL appear near the Info_Button showing the formula text for that Cost_Card.
3. WHEN the Formula_Tooltip is visible and the user clicks the Info_Button again, THE Formula_Tooltip SHALL close.
4. WHEN the Formula_Tooltip is visible and the user moves the mouse away from both the Info_Button and the Formula_Tooltip, THE Formula_Tooltip SHALL close after a 200-millisecond delay.
5. WHEN the Formula_Tooltip is visible and the user clicks outside the Formula_Tooltip, THE Formula_Tooltip SHALL close.

### Requirement 3: Overview Tab Formula Content

**User Story:** As a budget analyst, I want to see the specific formulas for Overview tab cards, so that I understand the high-level cost aggregation logic.

#### Acceptance Criteria

1. THE Formula_Tooltip for the "Full Year Resource Cost" card SHALL display: "Sum of all resourceData costs (actuals Jan-Mar + forecast Apr-Dec). Each line item = hours × hourly rate per employee per project per month."
2. THE Formula_Tooltip for the "Full Year AWS Cost" card SHALL display: "Sum of all awsData costs (actuals Jan-Mar + forecast Apr-Dec). Standard accounts use 3-month avg ± $300 variance × seasonality. Growth accounts use previous month × 1.05 × seasonality. Total capped at $2.1M."
3. THE Formula_Tooltip for the "Capital Expense (Resources)" card SHALL display: "Sum of resourceData costs where acctClass === 'Capital Expense' (all months, actuals + forecast)."
4. THE Formula_Tooltip for the "Operating Expense (Resources)" card SHALL display: "Sum of resourceData costs where acctClass === 'Operating Expense' (all months, actuals + forecast)."

### Requirement 4: Resource Tab Formula Content

**User Story:** As a budget analyst, I want to see the specific formulas for Resource tab cards, so that I understand how resource costs break down.

#### Acceptance Criteria

1. THE Formula_Tooltip for the "Capital Projects (Full Year)" card SHALL display: "Sum of resourceData costs where acctClass === 'Capital Expense'. Forecast hours = 3-month avg (Jan-Mar) ± 10hr variance × seasonality factor."
2. THE Formula_Tooltip for the "Operating Projects (Full Year)" card SHALL display: "Sum of resourceData costs where acctClass === 'Operating Expense'. Forecast hours = 3-month avg (Jan-Mar) ± 10hr variance × seasonality factor."
3. THE Formula_Tooltip for the "FTE Cost (Full Year)" card SHALL display: "Sum of resourceData costs where type === 'FTE'. Cost per line = hours × hourly rate. FTE rates range $90-$120/hr."
4. THE Formula_Tooltip for the "Contractor Cost (Full Year)" card SHALL display: "Sum of resourceData costs where type === 'Contractor'. Cost per line = hours × hourly rate. Contractor rates range $50-$105/hr."

### Requirement 5: AWS Tab Formula Content

**User Story:** As a budget analyst, I want to see the specific formulas for AWS tab cards, so that I understand the cloud cost forecasting methodology.

#### Acceptance Criteria

1. THE Formula_Tooltip for the "Full Year AWS Spend" card SHALL display: "Sum of all awsData costs across 45 accounts (actuals + forecast). Standard: 3-month avg ± $300 × AWS seasonality. Growth (AWS00008, AWS00011, AWS00027): prev month × 1.05 × AWS seasonality."
2. THE Formula_Tooltip for the "Annual Budget Cap" card SHALL display: "Hard-coded annual cap of $2,100,000. If raw forecast exceeds cap, all forecast values are scaled down proportionally: scaledCost = rawCost × (allowedForecast / totalRawForecast)."
3. THE Formula_Tooltip for the "Q1 Actuals" card SHALL display: "Sum of awsData costs where isActual === true (Jan, Feb, Mar actual spend across all 45 AWS accounts)."
4. THE Formula_Tooltip for the "Forecast (Apr-Dec)" card SHALL display: "Sum of awsData costs where isActual === false. After cap scaling applied. 9 months × 45 accounts projected."
5. THE Formula_Tooltip for the "Raw Forecast (No Cap)" card SHALL display: "awsData._rawFullYear — the total full-year cost before cap scaling is applied. Scale factor: allowedForecast / totalRawForecast. Reduction = rawFullYear - cappedFullYear."

### Requirement 6: Formula Tooltip Styling and Accessibility

**User Story:** As a user, I want the formula tooltip to be readable and accessible, so that I can easily consume the formula information regardless of device or assistive technology.

#### Acceptance Criteria

1. THE Formula_Tooltip SHALL have a white background, a subtle border or shadow, rounded corners, and a maximum width of 350 pixels.
2. THE Formula_Tooltip SHALL use a legible font size of at least 12 pixels with adequate line height for multi-line formulas.
3. THE Formula_Tooltip SHALL include an appropriate ARIA role of "tooltip" and the Info_Button SHALL reference the tooltip via aria-describedby.
4. THE Info_Button SHALL be keyboard accessible, responding to Enter and Space key presses the same as a click interaction.
5. THE Formula_Tooltip SHALL be dismissible via the Escape key when visible.
6. THE Formula_Tooltip SHALL be positioned to remain within the visible viewport, adjusting placement if near a screen edge.
