# Design Document: Cost Card Formula Info

## Overview

This design adds an info button (ℹ️) to each cost card in the Spectrum Automated Planning Tool. The button reveals a tooltip showing the formula/calculation used to derive the displayed value. The implementation is entirely within the single `index-original.html` file, using inline CSS and JavaScript consistent with the existing codebase patterns.

## Architecture

### Approach

Since the application is a single-file HTML app with inline `<style>` and `<script>` blocks, the implementation will:

1. Add CSS styles for the info button and tooltip to the existing `<style>` block
2. Add a reusable `createInfoButton(formulaText)` helper function that generates the HTML for an info button with its associated tooltip
3. Modify each render function (renderOverview, renderResource, renderAWS) to inject info buttons into card HTML using a formula lookup map
4. Add a global event handler for tooltip show/hide/dismiss logic

### Component Structure

```
Cost Card (.card)
├── Header row (h3 + Info_Button)
│   ├── h3 (card title)
│   └── button.info-btn (ℹ️ icon)
├── .value (cost figure)
├── .sub (subtitle)
└── .formula-tooltip (hidden by default, shown on interaction)
```

### Data Design

A `CARD_FORMULAS` object maps card titles to formula description strings. This centralizes all formula text in one place for easy maintenance.

```javascript
const CARD_FORMULAS = {
  // Overview tab
  "Full Year Resource Cost": "Sum of all resourceData costs...",
  "Full Year AWS Cost": "Sum of all awsData costs...",
  "Capital Expense (Resources)": "Sum of resourceData costs where acctClass === 'Capital Expense'...",
  "Operating Expense (Resources)": "Sum of resourceData costs where acctClass === 'Operating Expense'...",
  // Resource tab
  "Capital Projects (Full Year)": "Sum of resourceData costs where acctClass === 'Capital Expense'...",
  "Operating Projects (Full Year)": "Sum of resourceData costs where acctClass === 'Operating Expense'...",
  "FTE Cost (Full Year)": "Sum of resourceData costs where type === 'FTE'...",
  "Contractor Cost (Full Year)": "Sum of resourceData costs where type === 'Contractor'...",
  // AWS tab
  "Full Year AWS Spend": "Sum of all awsData costs across 45 accounts...",
  "Annual Budget Cap": "Hard-coded annual cap of $2,100,000...",
  "Q1 Actuals": "Sum of awsData costs where isActual === true...",
  "Forecast (Apr-Dec)": "Sum of awsData costs where isActual === false...",
  "Raw Forecast (No Cap)": "awsData._rawFullYear..."
};
```

### Interaction Logic

1. **Click toggle**: Clicking the info button toggles the tooltip visible/hidden. Clicking again hides it.
2. **Hover show**: Mouseenter on the info button starts a 300ms timer. If the mouse remains, the tooltip appears.
3. **Hover hide**: Mouseleave from both the button and tooltip starts a 200ms timer. If neither is re-entered, the tooltip hides.
4. **Outside click**: Clicking anywhere outside the tooltip closes it.
5. **Keyboard**: Enter/Space on the button toggles the tooltip. Escape closes any open tooltip.
6. **Viewport awareness**: Before showing, the tooltip checks its position and flips to the left or above if it would overflow the viewport.

### CSS Additions

```css
.card { position: relative; }
.card h3 { display: flex; align-items: center; gap: 6px; }
.info-btn {
  display: inline-flex; align-items: center; justify-content: center;
  width: 18px; height: 18px; border-radius: 50%;
  background: #e3f2fd; border: 1px solid #90caf9;
  color: #1565c0; font-size: 11px; cursor: pointer;
  line-height: 1; margin-left: auto; flex-shrink: 0;
  transition: background 0.2s;
}
.info-btn:hover, .info-btn:focus { background: #bbdefb; outline: none; }
.formula-tooltip {
  display: none; position: absolute; top: 100%; right: 0;
  background: white; border: 1px solid #ddd; border-radius: 8px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.12); padding: 12px 16px;
  max-width: 350px; min-width: 220px; font-size: 12px;
  line-height: 1.6; color: #333; z-index: 1000;
}
.formula-tooltip.visible { display: block; }
.formula-tooltip::before {
  content: ''; position: absolute; top: -6px; right: 14px;
  width: 10px; height: 10px; background: white;
  border-left: 1px solid #ddd; border-top: 1px solid #ddd;
  transform: rotate(45deg);
}
```

### Helper Function

```javascript
function cardWithInfo(title, valueHtml, subHtml) {
  const formula = CARD_FORMULAS[title] || '';
  const tooltipId = 'tip-' + title.replace(/[^a-zA-Z0-9]/g, '-').toLowerCase();
  const infoBtn = formula ? `<button class="info-btn" aria-label="Show formula for ${title}" aria-describedby="${tooltipId}" tabindex="0">ℹ</button>` : '';
  const tooltip = formula ? `<div class="formula-tooltip" id="${tooltipId}" role="tooltip">${formula}</div>` : '';
  return `<div class="card"><h3>${title}${infoBtn}</h3><div class="value">${valueHtml}</div><div class="sub">${subHtml}</div>${tooltip}</div>`;
}
```

### Event Handling

A single delegated event listener on `document` handles:
- Click events on `.info-btn` elements (toggle tooltip)
- Click events outside tooltips (close all)
- Keyboard events (Escape to close, Enter/Space on button to toggle)
- Mouseenter/mouseleave on `.info-btn` and `.formula-tooltip` elements (hover behavior with timers)

This avoids attaching individual handlers to each card and works with dynamically rendered content.

## File Changes

Only `index-original.html` is modified:

1. **CSS block** — Add styles for `.info-btn` and `.formula-tooltip` (and modify `.card`, `.card h3`)
2. **JavaScript** — Add `CARD_FORMULAS` object, `cardWithInfo()` helper, and tooltip event handling code
3. **renderOverview()** — Replace inline card HTML with `cardWithInfo()` calls
4. **renderResource()** — Replace inline card HTML with `cardWithInfo()` calls  
5. **renderAWS()** — Replace inline card HTML with `cardWithInfo()` calls

## Correctness Properties

1. Every Cost_Card in Overview, Resource, and AWS tabs contains exactly one Info_Button element.
2. Each Info_Button has a corresponding Formula_Tooltip with non-empty text content.
3. Clicking an Info_Button toggles the `.visible` class on its associated tooltip (and only that tooltip).
4. At most one Formula_Tooltip is visible at any given time across the entire page.
5. The tooltip's `id` attribute matches the `aria-describedby` value on the associated Info_Button.
6. Pressing Escape while a tooltip is visible removes the `.visible` class from all tooltips.
7. The tooltip element remains within the viewport boundaries when made visible.
