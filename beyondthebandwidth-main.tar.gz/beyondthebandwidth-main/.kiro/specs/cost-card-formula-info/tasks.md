# Tasks: Cost Card Formula Info

## Task 1: Add CSS styles for info button and tooltip

- [x] 1.1 Add `.card { position: relative; }` override and update `.card h3` to use flexbox (`display: flex; align-items: center; gap: 6px;`)
- [x] 1.2 Add `.info-btn` styles: 18px circle, `#e3f2fd` background, `#1565c0` text, `#90caf9` border, 11px font, cursor pointer, `margin-left: auto`
- [x] 1.3 Add `.info-btn:hover` and `.info-btn:focus` styles with `#bbdefb` background and outline removal
- [x] 1.4 Add `.formula-tooltip` styles: hidden by default, absolute positioned, white background, rounded corners, box-shadow, max-width 350px, min-width 220px, 12px font, z-index 1000
- [x] 1.5 Add `.formula-tooltip.visible { display: block; }` and the `::before` arrow pseudo-element

## Task 2: Add CARD_FORMULAS data object and cardWithInfo helper function

- [x] 2.1 Add the `CARD_FORMULAS` constant object with all 13 formula description strings (4 Overview + 4 Resource + 5 AWS cards)
- [x] 2.2 Add the `cardWithInfo(title, valueHtml, subHtml)` helper function that generates card HTML with embedded info button and tooltip

## Task 3: Add tooltip interaction event handlers

- [x] 3.1 Add delegated click handler on `document` for `.info-btn` that toggles the associated tooltip, closing any other open tooltips
- [x] 3.2 Add delegated click handler to close tooltips when clicking outside (document click that's not on `.info-btn` or `.formula-tooltip`)
- [x] 3.3 Add keyboard handler: Escape key closes all visible tooltips; Enter/Space on focused `.info-btn` toggles tooltip
- [x] 3.4 Add hover handlers with 300ms show delay on mouseenter and 200ms hide delay on mouseleave (for both `.info-btn` and `.formula-tooltip`)
- [x] 3.5 Add viewport boundary check that adjusts tooltip position (flip left/above) when it would overflow the screen edge

## Task 4: Update renderOverview to use cardWithInfo

- [x] 4.1 Replace the 4 inline card `<div>` elements in `renderOverview()` with calls to `cardWithInfo()` using the appropriate title, value, and subtitle strings

## Task 5: Update renderResource to use cardWithInfo

- [x] 5.1 Replace the 4 inline card `<div>` elements in `renderResource()` with calls to `cardWithInfo()` using the appropriate title, value, and subtitle strings

## Task 6: Update renderAWS to use cardWithInfo

- [x] 6.1 Replace the 5 inline card `<div>` elements in `renderAWS()` with calls to `cardWithInfo()` using the appropriate title, value, and subtitle strings

## Task 7: Verify and test

- [x] 7.1 Verify the file has no syntax errors by reviewing the final HTML structure
- [x] 7.2 Confirm all 13 cards across the three tabs render with info buttons and correct formula tooltips
