# Requirements Document

## Introduction

The Spectrum Automated Planning Tool currently supports two hardcoded use cases: resource project/cost forecasting and AWS hosting cost forecasting. This feature transforms the tool into a universal budget planner that dynamically adapts to any type of budgeting data uploaded by the user. The system will detect the structure and domain of uploaded data, generate appropriate dashboards and visualizations, and present contextually relevant scenario options — all without requiring code changes for new budget domains.

## Glossary

- **Data_Analyzer**: The module responsible for inspecting uploaded data columns, patterns, and values to classify the data domain and structure
- **Dashboard_Engine**: The module responsible for dynamically generating tabs, cards, charts, and tables based on analyzed data characteristics
- **Scenario_Engine**: The module responsible for generating and executing scenario options that are contextually relevant to the uploaded data domain
- **Domain**: A category of budgeting data (e.g., resource planning, AWS costs, marketing spend, facilities, software licensing)
- **Schema_Profile**: A detected description of the uploaded data including column names, data types, temporal columns, numeric columns, categorical columns, and hierarchical relationships
- **Upload_Manager**: The module responsible for ingesting files, parsing sheets, and coordinating data analysis
- **Metric_Card**: A summary card displaying a key aggregate value on the dashboard (e.g., total spend, count of items)
- **Forecast_Model**: The algorithm applied to project future values from historical data, selected based on data characteristics
- **Scenario_Option**: A pre-configured what-if adjustment presented to the user based on their data domain (e.g., "Add headcount" for resource data, "Increase ad spend 20%" for marketing data)

## Requirements

### Requirement 1: Universal Data Ingestion

**User Story:** As a budget planner, I want to upload any Excel file containing budgeting data, so that the tool works for my department regardless of the budget category.

#### Acceptance Criteria

1. WHEN an Excel file (.xlsx or .xls) is uploaded, THE Upload_Manager SHALL parse all sheets and extract column headers, data types (numeric, currency, date, text, boolean), and row counts without requiring a predefined schema
2. WHEN a CSV file (.csv) is uploaded, THE Upload_Manager SHALL parse the file and extract column headers, data types (numeric, currency, date, text, boolean), and row counts without requiring a predefined schema
3. WHEN an uploaded file contains multiple sheets, THE Upload_Manager SHALL process each sheet independently and present the detected Schema_Profile for each sheet
4. IF an uploaded file contains no parseable tabular data (fewer than 1 header row and 1 data row in any sheet), THEN THE Upload_Manager SHALL display an error message indicating that no valid data was found and list the supported formats (.xlsx, .xls, .csv)
5. WHEN a file is uploaded, THE Upload_Manager SHALL accept files up to 50 MB in size
6. IF an uploaded file exceeds 50 MB, THEN THE Upload_Manager SHALL reject the file and display an error message indicating the file size limit of 50 MB
7. IF an uploaded file is not in a supported format (.xlsx, .xls, .csv), THEN THE Upload_Manager SHALL reject the file and display an error message indicating the supported file formats
8. WHEN a supported file is uploaded that contains at least 1 header row and 1 data row, THE Upload_Manager SHALL complete parsing and present results within 30 seconds

### Requirement 2: Automatic Data Classification

**User Story:** As a budget planner, I want the tool to automatically understand what kind of budgeting data I uploaded, so that I do not need to manually configure the tool for my data type.

#### Acceptance Criteria

1. WHEN data is parsed, THE Data_Analyzer SHALL identify temporal columns (dates, months, quarters, years) by inspecting column names and cell values — a column is classified as temporal if its name contains date-related keywords (date, month, quarter, year, period) OR if more than 80% of its non-empty values parse as valid dates or month abbreviations
2. WHEN data is parsed, THE Data_Analyzer SHALL identify numeric/currency columns that represent monetary values by inspecting column names for currency keywords (cost, spend, budget, revenue, amount, price, rate, fee) and by detecting that more than 90% of non-empty values are numeric or match currency patterns ($X,XXX.XX)
3. WHEN data is parsed, THE Data_Analyzer SHALL identify categorical columns by detecting columns where the number of distinct non-empty values is between 2 and 50 (inclusive) and the values are of type text
4. WHEN data is parsed, THE Data_Analyzer SHALL identify hierarchical relationships between categorical columns by detecting parent-child value nesting patterns where each value in a child column maps to exactly one value in a parent column across all rows
5. WHEN data is parsed, THE Data_Analyzer SHALL classify the data domain by matching the Schema_Profile against known domain signatures (resource planning, cloud costs, marketing, facilities, licensing, general budget)
6. IF the Data_Analyzer cannot match data to a known domain with confidence above 60%, THEN THE Data_Analyzer SHALL classify the data as "general budget" and proceed with generic analysis heuristics
7. WHEN classification is complete, THE Data_Analyzer SHALL display the detected Schema_Profile summary to the user including identified domain, temporal range, monetary columns, and categorical groupings

### Requirement 3: Dynamic Dashboard Generation

**User Story:** As a budget planner, I want the dashboard to automatically create relevant tabs, charts, and summary cards based on my data, so that I get useful visualizations without manual configuration.

#### Acceptance Criteria

1. WHEN data analysis is complete, THE Dashboard_Engine SHALL generate an Overview tab containing Metric_Cards for total spend, period-over-period percentage change compared to the most recent two periods, and count of distinct items in the primary categorical column
2. WHEN temporal columns and monetary columns are detected, THE Dashboard_Engine SHALL generate a time-series chart showing spend over the detected time periods
3. WHEN categorical columns are detected, THE Dashboard_Engine SHALL generate one tab per categorical column that contains 20 or fewer distinct values, up to a maximum of 8 generated category tabs, each containing breakdown charts and tables for that category
4. WHEN hierarchical relationships are detected, THE Dashboard_Engine SHALL generate drill-down charts that allow filtering from the top-level category to subcategories
5. WHEN two or more monetary columns are detected, THE Dashboard_Engine SHALL generate a comparison view displaying each monetary column side-by-side with the computed variance between them for each row grouping
6. THE Dashboard_Engine SHALL generate a Detail Tables tab containing the full uploaded data in a sortable, filterable table format with paginated display showing 100 rows per page
7. WHEN the Dashboard_Engine generates tabs, THE Dashboard_Engine SHALL label each tab using the column name or domain-specific terminology derived from the data rather than generic labels
8. IF no categorical columns are detected in the uploaded data, THEN THE Dashboard_Engine SHALL generate only the Overview tab, the time-series chart (when temporal data exists), and the Detail Tables tab

### Requirement 4: Adaptive Forecasting

**User Story:** As a budget planner, I want the tool to forecast future values based on whatever historical data I upload, so that I can project costs forward regardless of my budget category.

#### Acceptance Criteria

1. WHEN temporal data spans three or more periods, THE Forecast_Model SHALL generate a forward projection for the next 3 periods (matching the detected period granularity) using a weighted moving average where the most recent period receives double the weight of earlier periods
2. WHEN a growth trend is detected (3 or more consecutive periods each showing a period-over-period increase exceeding 10%), THE Forecast_Model SHALL apply a compound growth projection for those line items instead of the weighted moving average
3. WHEN seasonal patterns are detected (a repeating variance of 15% or more from the mean at the same relative position across at least 2 full cycles of 12 or more periods), THE Forecast_Model SHALL apply seasonal adjustment factors to the projection in addition to the base projection method
4. WHEN fewer than three temporal periods are present, THE Forecast_Model SHALL use a simple average as the projection basis and display a "Low Confidence" label adjacent to each projected value
5. THE Forecast_Model SHALL label all projected values with the text "Forecast" and all original values with the text "Actual" in both charts and tables, using visually distinct styling (e.g., dashed line for forecast, solid line for actual)
6. WHEN a forecast dashboard is displayed, THE Forecast_Model SHALL allow the user to override default projection parameters (growth rate as a percentage between 0% and 200%, seasonality factors as multipliers between 0.1 and 3.0) via an Assumptions panel
7. IF both a growth trend and seasonal patterns are detected for the same line item, THEN THE Forecast_Model SHALL apply the compound growth projection as the base and layer seasonal adjustment factors on top of the growth-adjusted values

### Requirement 5: Context-Aware Scenario Builder

**User Story:** As a budget planner, I want the Scenario Builder to present me with what-if options that are relevant to my specific data, so that I can model realistic changes without building scenarios from scratch.

#### Acceptance Criteria

1. WHEN data classification is complete, THE Scenario_Engine SHALL populate a dropdown of Scenario_Options that are relevant to the detected domain within 2 seconds of classification completing
2. WHEN the domain is classified as resource planning, THE Scenario_Engine SHALL present scenario options including: add headcount, remove headcount, adjust rates, shift project allocations, and extend or end projects
3. WHEN the domain is classified as cloud/hosting costs, THE Scenario_Engine SHALL present scenario options including: add accounts, remove accounts, apply growth rate change, and set cost cap
4. WHEN the domain is classified as marketing spend, THE Scenario_Engine SHALL present scenario options including: adjust channel budget, shift spend between channels, add campaign, and apply seasonal uplift
5. WHEN the domain is classified as general budget, THE Scenario_Engine SHALL present scenario options including: increase line item by percentage, decrease line item by percentage, add new line item, and remove line item
6. WHEN a Scenario_Option is selected, THE Scenario_Engine SHALL display input controls appropriate to that scenario: numeric inputs for percentages constrained to the range -100% to +1000%, dropdowns for categorical selections populated from detected categorical column values, and date pickers for temporal bounds constrained to the detected temporal range
7. WHEN the user confirms scenario parameters by activating a "Calculate" control, THE Scenario_Engine SHALL recalculate the forecast within 3 seconds incorporating the scenario adjustment and display the impact as both an absolute currency delta and a percentage change against the baseline forecast
8. THE Scenario_Engine SHALL allow the user to apply up to 10 Scenario_Options simultaneously, display the combined impact, and allow individual scenarios to be removed or modified independently without resetting the remaining active scenarios
9. IF the user submits scenario parameters that are invalid (non-numeric value in a numeric field, percentage outside -100% to +1000%, or date outside the detected temporal range), THEN THE Scenario_Engine SHALL display an inline error message indicating the validation failure and SHALL NOT trigger recalculation until valid parameters are provided
10. WHEN multiple Scenario_Options affect the same line item, THE Scenario_Engine SHALL apply adjustments in the order they were added and display the individual contribution of each scenario to the combined delta

### Requirement 6: Backward Compatibility with Existing Data

**User Story:** As a current user of the tool, I want my existing resource planning and AWS cost data to continue working seamlessly, so that the universal upgrade does not break my current workflow.

#### Acceptance Criteria

1. WHEN an uploaded file contains sheets or files with column headers matching the existing resource planning schema (roster: employee id, employee name, type, hourly rate; projects: project number, project name, accounting classification; time allocations: employee id, project number, monthly hours), THE Data_Analyzer SHALL detect it as resource planning domain within the same upload session
2. WHEN data is detected as resource planning domain, THE Dashboard_Engine SHALL generate tabs labeled Overview, Resource Forecast, AWS Hosting, Detail Tables, Assumptions, and Scenario Builder with the same chart types, metric cards, and table structures as the current tool
3. WHEN an uploaded file contains column headers matching the existing AWS accounts schema (account number, employee id, monthly costs) and resource planning data is present in the same upload session, THE Data_Analyzer SHALL detect it as cloud costs and THE Dashboard_Engine SHALL integrate it into the dashboard as an AWS Hosting tab
4. THE Upload_Manager SHALL support the existing multi-file upload workflow where roster, projects, time allocations, and AWS accounts are uploaded as separate files or separate sheets within a single file, in any order within the same session
5. IF an uploaded file contains some but not all columns of the existing resource planning or AWS accounts schema, THEN THE Data_Analyzer SHALL classify the data using the general domain detection logic defined in Requirement 2 rather than forcing a partial match to the legacy schema
6. WHEN only resource planning data is uploaded without AWS accounts data, THE Dashboard_Engine SHALL generate all tabs except AWS Hosting and SHALL display a message on the AWS tab indicating that no cloud cost data was detected

### Requirement 7: Data Profile Display and User Confirmation

**User Story:** As a budget planner, I want to see what the tool detected about my data before generating the dashboard, so that I can confirm the analysis is correct or make adjustments.

#### Acceptance Criteria

1. WHEN data analysis is complete, THE Data_Analyzer SHALL display a confirmation panel showing: detected domain, number of records, identified temporal range displayed as start and end boundaries (e.g., "Jan 2023 – Dec 2024"), monetary columns with up to 3 sample values each, and categorical groupings with the count of distinct values per group
2. WHEN the confirmation panel is displayed, THE Upload_Manager SHALL provide a "Generate Dashboard" button that proceeds with dashboard generation using the confirmed profile
3. WHEN the confirmation panel is displayed, THE Upload_Manager SHALL provide controls to override the detected domain classification by selecting from the list of known domains (resource planning, cloud costs, marketing, facilities, licensing, general budget), and SHALL provide controls to reassign individual column classifications (temporal, monetary, categorical, or excluded)
4. IF the user overrides the domain classification, THEN THE Scenario_Engine SHALL update the available Scenario_Options to match the user-selected domain, and THE Dashboard_Engine SHALL regenerate the dashboard layout using domain-appropriate tabs and visualizations for the newly selected domain
5. IF the Data_Analyzer cannot determine a temporal range or cannot identify at least one monetary column, THEN THE Data_Analyzer SHALL display the confirmation panel with a warning indicator on each unresolved field and SHALL still allow the user to proceed with dashboard generation or manually assign column classifications
6. WHEN the user modifies any column classification or domain override on the confirmation panel, THE Data_Analyzer SHALL update the confirmation panel summary to reflect the revised profile before the user proceeds with dashboard generation

### Requirement 8: Export and Sharing

**User Story:** As a budget planner, I want to export my forecasted data and scenario results, so that I can share the analysis with stakeholders.

#### Acceptance Criteria

1. WHEN a dashboard is generated, THE Dashboard_Engine SHALL provide a CSV export button that downloads forecast data containing all time periods, all line items, their actual values, projected values labeled as "Forecast", and the categorical groupings used in the dashboard
2. WHEN scenario parameters are configured and results are calculated, THE Scenario_Engine SHALL provide an export button that downloads a CSV file containing each line item with its baseline forecast value, scenario-adjusted value, and the delta between them for all affected time periods
3. IF multiple Scenario_Options are applied simultaneously, THEN THE Scenario_Engine SHALL include all active scenario adjustments and their combined impact in a single exported CSV file
4. IF a CSV export fails due to the browser or system being unable to complete the download, THEN THE system SHALL display an error message indicating the export could not be completed and retain the export button in an actionable state for retry
