# Spectrum Automated Planning Tool

A single-page budgeting and forecasting application for 2026 organizational planning. Projects resource costs and AWS hosting spend across a 30-person team, 20 projects, and 45 AWS accounts using a 3-month average methodology with variance modeling.

## What It Does

- Forecasts full-year 2026 budget from Q1 actuals (Jan–Mar) through Dec
- Splits costs by Capital Expense vs Operating Expense, FTE vs Contractor, and Business Unit
- Enforces a $2.1M annual AWS budget cap with automatic proportional scaling
- Models seasonality (reduced productivity in summer/holidays, increased PTO)
- Handles project wind-downs (freed hours redistributed to active work)
- Tracks 5% month-over-month growth for designated AWS accounts
- Provides an interactive Scenario Builder for drag-and-drop "what if" planning

## Tabs

| Tab | Purpose |
|---|---|
| Overview | Executive summary, KPI cards, 6 charts (monthly trends, BU breakdown, type splits) |
| Resource Forecast | Project cost table, SVP leader breakdown, CapEx/OpEx by month |
| AWS Hosting | 45-account detail, growth trajectories, budget cap enforcement |
| Detail Tables | Employee-level forecast detail, CSV export |
| Assumptions & Methodology | Model documentation, seasonality factors, variance rules |
| Scenario Builder | Create future projects, assign employees, see live cost projections |

## Tech Stack

| Layer | Technology |
|---|---|
| Structure | Single HTML file, no build step |
| Charts | [Chart.js](https://www.chartjs.org/) (CDN) |
| Styling | Inline CSS with CSS Grid, Flexbox, responsive breakpoints |
| Logic | Vanilla JavaScript (no framework) |
| Data | Hardcoded arrays (roster, projects, time allocations, AWS accounts) |
| Hosting | Static file — open directly in browser or serve from any web server |

No dependencies to install. No bundler, no Node.js, no package.json.

## How to Run

Open `index.html` in any modern browser:

```
# Double-click the file, or:
start index.html          # Windows
open index.html           # macOS
xdg-open index.html       # Linux
```

Or serve locally if you prefer:

```
npx serve .
# Then open http://localhost:3000
```

## Forecasting Model

**Resource hours:** 3-month average per employee-project pair, with ±10 hour random variance and a monthly seasonality multiplier:

| Month | Factor | Month | Factor |
|---|---|---|---|
| Jan–Apr | 1.0 | May | 0.95 |
| Jun | 0.90 | Jul | 0.85 |
| Aug | 0.90 | Sep | 1.0 |
| Oct | 1.0 | Nov | 0.90 |
| Dec | 0.80 | | |

**PTO:** Distributed across the year by seasonal weight. FTEs cap at 160 hrs/year, contractors at 120 hrs/year.

**AWS costs:** 3-month average ±$300 variance for standard accounts. Growth accounts (AWS00008, AWS00011, AWS00027) compound at 5% MoM from March baseline. AWS seasonality reduces costs slightly in summer (93–95%) and December (90%). If the full-year total exceeds the $2.1M cap, all forecast months scale down proportionally.

**Project endings:** P00010 (WiFi Connectivity) and P00014 (CPE Enhancements) end after August. Freed capacity redistributes to remaining active projects at a 1.20× boost factor.

## Project Structure

```
beyondthebandwidth/
├── index.html      # The entire application (HTML + CSS + JS)
├── README.md       # This file
└── TESTING.md      # Chrome DevTools test documentation
```

## Data Shape

- **Roster:** 30 employees (17 FTE, 13 Contractors) across 7 locations
- **Projects:** 20 projects (14 CapEx, 6 OpEx) across 5 business units
- **Time allocations:** Employee-project-month hour assignments (Q1 actuals)
- **AWS accounts:** 45 accounts with Q1 monthly cost actuals and owner assignments

## Browser Support

Tested in Chrome. Should work in any modern browser that supports ES6, CSS Grid, and Chart.js 4.x.

## Contributing

This is an internal planning tool. To update:

1. Edit the data arrays at the top of the `<script>` block in `index.html`
2. Refresh the browser — forecasts recalculate on page load
3. Use the Scenario Builder tab for ad-hoc "what if" analysis without changing source

## Repository

```
git remote: https://gitlab.spectrumflow.net/Olivia.Jenkins/beyondthebandwidth.git
```
